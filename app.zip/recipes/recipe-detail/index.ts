export { RecipeDetailComponent } from './recipe-detail.component';
